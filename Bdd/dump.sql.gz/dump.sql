--
-- PostgreSQL database dump
--

-- Dumped from database version 10.3
-- Dumped by pg_dump version 10.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: catastrophe; Type: TABLE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE TABLE public.catastrophe (
    id_catastrophe integer NOT NULL,
    type_catastrophe character varying(8) NOT NULL
);


ALTER TABLE public.catastrophe OWNER TO marjorieandrieux_marjo;

--
-- Name: catastrophe_id_catastrophe_seq; Type: SEQUENCE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE SEQUENCE public.catastrophe_id_catastrophe_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catastrophe_id_catastrophe_seq OWNER TO marjorieandrieux_marjo;

--
-- Name: catastrophe_id_catastrophe_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER SEQUENCE public.catastrophe_id_catastrophe_seq OWNED BY public.catastrophe.id_catastrophe;


--
-- Name: partie; Type: TABLE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE TABLE public.partie (
    id_partie integer NOT NULL,
    date_partie date NOT NULL,
    annee_simu_partie integer NOT NULL
);


ALTER TABLE public.partie OWNER TO marjorieandrieux_marjo;

--
-- Name: partie_id_partie_seq; Type: SEQUENCE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE SEQUENCE public.partie_id_partie_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.partie_id_partie_seq OWNER TO marjorieandrieux_marjo;

--
-- Name: partie_id_partie_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER SEQUENCE public.partie_id_partie_seq OWNED BY public.partie.id_partie;


--
-- Name: partie_ville; Type: TABLE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE TABLE public.partie_ville (
    id_ville integer NOT NULL,
    id_partie integer NOT NULL
);


ALTER TABLE public.partie_ville OWNER TO marjorieandrieux_marjo;

--
-- Name: partie_ville_catastrophe; Type: TABLE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE TABLE public.partie_ville_catastrophe (
    id_partie integer NOT NULL,
    id_catastrophe integer NOT NULL,
    id_ville integer NOT NULL,
    annee_partvillecata integer
);


ALTER TABLE public.partie_ville_catastrophe OWNER TO marjorieandrieux_marjo;

--
-- Name: ville; Type: TABLE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE TABLE public.ville (
    id_ville integer NOT NULL,
    pop_initiale_ville integer NOT NULL,
    tx_natalite_ville double precision NOT NULL,
    tx_mortalite_ville double precision NOT NULL
);


ALTER TABLE public.ville OWNER TO marjorieandrieux_marjo;

--
-- Name: ville_id_ville_seq; Type: SEQUENCE; Schema: public; Owner: marjorieandrieux_marjo
--

CREATE SEQUENCE public.ville_id_ville_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ville_id_ville_seq OWNER TO marjorieandrieux_marjo;

--
-- Name: ville_id_ville_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER SEQUENCE public.ville_id_ville_seq OWNED BY public.ville.id_ville;


--
-- Name: catastrophe id_catastrophe; Type: DEFAULT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.catastrophe ALTER COLUMN id_catastrophe SET DEFAULT nextval('public.catastrophe_id_catastrophe_seq'::regclass);


--
-- Name: partie id_partie; Type: DEFAULT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie ALTER COLUMN id_partie SET DEFAULT nextval('public.partie_id_partie_seq'::regclass);


--
-- Name: ville id_ville; Type: DEFAULT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.ville ALTER COLUMN id_ville SET DEFAULT nextval('public.ville_id_ville_seq'::regclass);


--
-- Data for Name: catastrophe; Type: TABLE DATA; Schema: public; Owner: marjorieandrieux_marjo
--

INSERT INTO public.catastrophe VALUES (1, 'eau');
INSERT INTO public.catastrophe VALUES (2, 'feu');
INSERT INTO public.catastrophe VALUES (3, 'terre');
INSERT INTO public.catastrophe VALUES (4, 'vent');
INSERT INTO public.catastrophe VALUES (5, 'épidémie');
INSERT INTO public.catastrophe VALUES (6, 'guerre');


--
-- Data for Name: partie; Type: TABLE DATA; Schema: public; Owner: marjorieandrieux_marjo
--



--
-- Data for Name: partie_ville; Type: TABLE DATA; Schema: public; Owner: marjorieandrieux_marjo
--



--
-- Data for Name: partie_ville_catastrophe; Type: TABLE DATA; Schema: public; Owner: marjorieandrieux_marjo
--



--
-- Data for Name: ville; Type: TABLE DATA; Schema: public; Owner: marjorieandrieux_marjo
--



--
-- Name: catastrophe_id_catastrophe_seq; Type: SEQUENCE SET; Schema: public; Owner: marjorieandrieux_marjo
--

SELECT pg_catalog.setval('public.catastrophe_id_catastrophe_seq', 8, true);


--
-- Name: partie_id_partie_seq; Type: SEQUENCE SET; Schema: public; Owner: marjorieandrieux_marjo
--

SELECT pg_catalog.setval('public.partie_id_partie_seq', 1, false);


--
-- Name: ville_id_ville_seq; Type: SEQUENCE SET; Schema: public; Owner: marjorieandrieux_marjo
--

SELECT pg_catalog.setval('public.ville_id_ville_seq', 1, false);


--
-- Name: catastrophe catastrophe_pk; Type: CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.catastrophe
    ADD CONSTRAINT catastrophe_pk PRIMARY KEY (id_catastrophe);


--
-- Name: partie partie_pk; Type: CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie
    ADD CONSTRAINT partie_pk PRIMARY KEY (id_partie);


--
-- Name: partie_ville_catastrophe partie_ville_catastrophe_pk; Type: CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville_catastrophe
    ADD CONSTRAINT partie_ville_catastrophe_pk PRIMARY KEY (id_partie, id_catastrophe, id_ville);


--
-- Name: partie_ville partie_ville_pk; Type: CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville
    ADD CONSTRAINT partie_ville_pk PRIMARY KEY (id_ville, id_partie);


--
-- Name: ville ville_pk; Type: CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.ville
    ADD CONSTRAINT ville_pk PRIMARY KEY (id_ville);


--
-- Name: partie_ville_catastrophe partie_ville_catastrophe_catastrophe0_fk; Type: FK CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville_catastrophe
    ADD CONSTRAINT partie_ville_catastrophe_catastrophe0_fk FOREIGN KEY (id_catastrophe) REFERENCES public.catastrophe(id_catastrophe);


--
-- Name: partie_ville_catastrophe partie_ville_catastrophe_partie_fk; Type: FK CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville_catastrophe
    ADD CONSTRAINT partie_ville_catastrophe_partie_fk FOREIGN KEY (id_partie) REFERENCES public.partie(id_partie);


--
-- Name: partie_ville_catastrophe partie_ville_catastrophe_ville1_fk; Type: FK CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville_catastrophe
    ADD CONSTRAINT partie_ville_catastrophe_ville1_fk FOREIGN KEY (id_ville) REFERENCES public.ville(id_ville);


--
-- Name: partie_ville partie_ville_partie0_fk; Type: FK CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville
    ADD CONSTRAINT partie_ville_partie0_fk FOREIGN KEY (id_partie) REFERENCES public.partie(id_partie);


--
-- Name: partie_ville partie_ville_ville_fk; Type: FK CONSTRAINT; Schema: public; Owner: marjorieandrieux_marjo
--

ALTER TABLE ONLY public.partie_ville
    ADD CONSTRAINT partie_ville_ville_fk FOREIGN KEY (id_ville) REFERENCES public.ville(id_ville);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO marjorieandrieux_marjo;
GRANT ALL ON SCHEMA public TO marjorieandrieux;


--
-- Name: TABLE catastrophe; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON TABLE public.catastrophe TO marjorieandrieux;


--
-- Name: SEQUENCE catastrophe_id_catastrophe_seq; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON SEQUENCE public.catastrophe_id_catastrophe_seq TO marjorieandrieux;


--
-- Name: TABLE partie; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON TABLE public.partie TO marjorieandrieux;


--
-- Name: SEQUENCE partie_id_partie_seq; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON SEQUENCE public.partie_id_partie_seq TO marjorieandrieux;


--
-- Name: TABLE partie_ville; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON TABLE public.partie_ville TO marjorieandrieux;


--
-- Name: TABLE partie_ville_catastrophe; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON TABLE public.partie_ville_catastrophe TO marjorieandrieux;


--
-- Name: TABLE ville; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON TABLE public.ville TO marjorieandrieux;


--
-- Name: SEQUENCE ville_id_ville_seq; Type: ACL; Schema: public; Owner: marjorieandrieux_marjo
--

GRANT ALL ON SEQUENCE public.ville_id_ville_seq TO marjorieandrieux;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: marjorieandrieux
--

ALTER DEFAULT PRIVILEGES FOR ROLE marjorieandrieux GRANT ALL ON SEQUENCES  TO marjorieandrieux_marjo;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: marjorieandrieux_marjo
--

ALTER DEFAULT PRIVILEGES FOR ROLE marjorieandrieux_marjo GRANT ALL ON SEQUENCES  TO marjorieandrieux;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: marjorieandrieux
--

ALTER DEFAULT PRIVILEGES FOR ROLE marjorieandrieux GRANT ALL ON FUNCTIONS  TO marjorieandrieux_marjo;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: marjorieandrieux_marjo
--

ALTER DEFAULT PRIVILEGES FOR ROLE marjorieandrieux_marjo GRANT ALL ON FUNCTIONS  TO marjorieandrieux;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: marjorieandrieux
--

ALTER DEFAULT PRIVILEGES FOR ROLE marjorieandrieux GRANT ALL ON TABLES  TO marjorieandrieux_marjo;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: marjorieandrieux_marjo
--

ALTER DEFAULT PRIVILEGES FOR ROLE marjorieandrieux_marjo GRANT ALL ON TABLES  TO marjorieandrieux;


--
-- PostgreSQL database dump complete
--

